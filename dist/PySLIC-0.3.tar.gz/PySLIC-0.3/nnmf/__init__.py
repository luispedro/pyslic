import lee_seung as ls
from hoyer import sparse_nnmf
import hoyer
lee_seung = ls.nnmf

__all__ = ['lee_seung','sparse_nnmf']
