from __future__ import division
from numpy import *
from classifier import classifier
from scipy.stats import entropy

def _informationgain(features,q,v,labels):
    N,_=features.shape
    less = (features[:,q] < v)
    frac = less.sum()/N
    return - frac * entropy(labels[less]) - (1.-frac)*entropy(labels[~less])
    
def best_attr(features,labels,value):
    _,q = features.shape
    solution=None
    best=-inf
    for i in xrange(q):
        valsq=features[:,i].copy()
        valsq.sort()
        valsq=unique(valsq)
        for v in valsq:
            now = value(features,i,v,labels)
            if now > best:
                solution = (i,v)
                best = now
    return solution

class stump(classifier):
    def __init__(self):
        classifier.__init__(self)

    def is_multi_class(self):
        return False

    def _dotrain(self,features,labels):
        N = features.shape[0]
        q,v = best_attr(features,labels,_informationgain)
        idxs=features[:,q] > v
        self._division = q,v
        ones=labels[idxs].sum()
        self._positive = int(ones > N//2)

    def _doapply(self,features):
        q,v = self._division
        val = int(features[q] > v)
        if self._positive:
            return int(val)
        return int(~val)

class tree(classifier):
    def __init__(self):
        classifier.__init__(self)

    
                

# vim: set ts=4 sts=4 sw=4 expandtab smartindent:
