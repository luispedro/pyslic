# -*- coding: utf-8 -*-
# Copyright (C) 2008  Murphy Lab
# Carnegie Mellon University
# 
# Written by Luís Pedro Coelho <lpc@cmu.edu>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published
# by the Free Software Foundation; either version 2 of the License,
# or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#
# For additional information visit http://murphylab.web.cmu.edu or
# send email to murphy@cmu.edu

from __future__ import division
from numpy import *
from classifier import classifier
from scipy.stats import entropy

def _informationgain(features,q,v,labels):
    N,_=features.shape
    less = (features[:,q] < v)
    frac = less.sum()/N
    return - frac * entropy(labels[less]) - (1.-frac)*entropy(labels[~less])
    
def best_attr(features,labels,value):
    _,q = features.shape
    solution=None
    best=-inf
    for i in xrange(q):
        valsq=features[:,i].copy()
        valsq.sort()
        valsq=unique(valsq)
        for v in valsq:
            now = value(features,i,v,labels)
            if now > best:
                solution = (i,v)
                best = now
    return solution

class stump(classifier):
    def __init__(self):
        classifier.__init__(self)

    def is_multi_class(self):
        return False

    def _dotrain(self,features,labels):
        N = features.shape[0]
        q,v = best_attr(features,labels,_informationgain)
        idxs=features[:,q] > v
        self._division = q,v
        ones=labels[idxs].sum()
        self._positive = int(ones > N//2)

    def _doapply(self,features):
        q,v = self._division
        val = int(features[q] > v)
        if self._positive:
            return int(val)
        return int(~val)

class tree(classifier):
    def __init__(self):
        classifier.__init__(self)

    
                

# vim: set ts=4 sts=4 sw=4 expandtab smartindent:
